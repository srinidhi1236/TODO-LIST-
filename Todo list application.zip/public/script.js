// ── State ──────────────────────────────────────────────────────────────────
let tasks = loadTasks();
let currentFilter = 'all';

// ── DOM references ─────────────────────────────────────────────────────────
const taskInput    = document.getElementById('taskInput');
const addBtn       = document.getElementById('addBtn');
const taskList     = document.getElementById('taskList');
const emptyState   = document.getElementById('emptyState');
const emptyText    = document.getElementById('emptyText');
const footer       = document.getElementById('footer');
const remainingEl  = document.getElementById('remainingCount');
const clearBtn     = document.getElementById('clearBtn');
const filterBtns   = document.querySelectorAll('.filter-btn');

// ── Init ───────────────────────────────────────────────────────────────────
render();

// ── Event listeners ────────────────────────────────────────────────────────
addBtn.addEventListener('click', addTask);

taskInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') addTask();
});

clearBtn.addEventListener('click', clearCompleted);

filterBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    currentFilter = btn.dataset.filter;
    filterBtns.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    render();
  });
});

// ── Core functions ─────────────────────────────────────────────────────────
function addTask() {
  const text = taskInput.value.trim();
  if (!text) {
    shake(taskInput);
    return;
  }

  tasks.unshift({ id: Date.now(), text, completed: false });
  saveTasks();
  render();
  taskInput.value = '';
  taskInput.focus();
}

function toggleTask(id) {
  const task = tasks.find((t) => t.id === id);
  if (task) task.completed = !task.completed;
  saveTasks();
  render();
}

function deleteTask(id) {
  tasks = tasks.filter((t) => t.id !== id);
  saveTasks();
  render();
}

function clearCompleted() {
  tasks = tasks.filter((t) => !t.completed);
  saveTasks();
  render();
}

// ── Render ─────────────────────────────────────────────────────────────────
function render() {
  const visible = tasks.filter((t) => {
    if (currentFilter === 'active')    return !t.completed;
    if (currentFilter === 'completed') return t.completed;
    return true;
  });

  taskList.innerHTML = '';

  visible.forEach((task) => {
    const li = document.createElement('li');
    li.className = 'task-item' + (task.completed ? ' done' : '');
    li.dataset.id = task.id;

    // Checkbox
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'task-checkbox';
    cb.checked = task.completed;
    cb.setAttribute('aria-label', 'Mark task as ' + (task.completed ? 'incomplete' : 'complete'));
    cb.addEventListener('change', () => toggleTask(task.id));

    // Label
    const label = document.createElement('label');
    label.className = 'task-label';
    label.textContent = task.text;
    label.addEventListener('click', () => toggleTask(task.id));

    // Delete button
    const del = document.createElement('button');
    del.className = 'delete-btn';
    del.setAttribute('aria-label', 'Delete task');
    del.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 4L4 12M4 4l8 8" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/>
      </svg>`;
    del.addEventListener('click', () => deleteTask(task.id));

    li.append(cb, label, del);
    taskList.appendChild(li);
  });

  // Empty state
  const hasVisibleTasks = visible.length > 0;
  emptyState.hidden = hasVisibleTasks;
  if (!hasVisibleTasks) {
    const messages = {
      all:       'No tasks yet. Add one above!',
      active:    'No active tasks. Great work! 🎉',
      completed: 'No completed tasks yet.',
    };
    emptyText.textContent = messages[currentFilter];
  }

  // Footer
  const activeCount = tasks.filter((t) => !t.completed).length;
  const hasCompleted = tasks.some((t) => t.completed);
  footer.hidden = tasks.length === 0;
  remainingEl.textContent = activeCount === 1 ? '1 task remaining' : `${activeCount} tasks remaining`;
  clearBtn.style.visibility = hasCompleted ? 'visible' : 'hidden';
}

// ── LocalStorage ───────────────────────────────────────────────────────────
function saveTasks() {
  localStorage.setItem('taskflow_tasks', JSON.stringify(tasks));
}

function loadTasks() {
  try {
    return JSON.parse(localStorage.getItem('taskflow_tasks')) || [];
  } catch {
    return [];
  }
}

// ── Shake animation for empty input ───────────────────────────────────────
function shake(el) {
  el.style.animation = 'none';
  el.offsetHeight; // reflow
  el.style.animation = 'shake 0.35s ease';
  el.addEventListener('animationend', () => { el.style.animation = ''; }, { once: true });
}
