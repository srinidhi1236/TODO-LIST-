import { useState, useEffect, useRef } from "react";

type Priority = "low" | "medium" | "high";

interface Task {
  id: string;
  text: string;
  completed: boolean;
  priority: Priority;
  category: string;
  reminderTime: string;
  reminderFired: boolean;
  createdAt: number;
  dueDate: string;
  notes: string;
}

const CATEGORIES = ["Personal", "Work", "Health", "Shopping", "Learning", "Other"];
const PRIORITY_COLORS: Record<Priority, string> = {
  low: "bg-emerald-100 text-emerald-700 border-emerald-200",
  medium: "bg-amber-100 text-amber-700 border-amber-200",
  high: "bg-rose-100 text-rose-700 border-rose-200",
};
const PRIORITY_DOT: Record<Priority, string> = {
  low: "bg-emerald-500",
  medium: "bg-amber-500",
  high: "bg-rose-500",
};

function genId() {
  return Math.random().toString(36).slice(2, 10);
}

function formatTime(iso: string) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function RobotIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="16" y="22" width="32" height="28" rx="6" fill="white" stroke="#0d9488" strokeWidth="2" />
      <rect x="22" y="28" width="8" height="6" rx="2" fill="#0d9488" />
      <rect x="34" y="28" width="8" height="6" rx="2" fill="#0d9488" />
      <rect x="26" y="38" width="12" height="4" rx="2" fill="#2dd4bf" />
      <rect x="28" y="14" width="8" height="10" rx="2" fill="white" stroke="#0d9488" strokeWidth="2" />
      <circle cx="32" cy="12" r="3" fill="#2dd4bf" />
      <rect x="8" y="32" width="6" height="12" rx="3" fill="white" stroke="#0d9488" strokeWidth="2" />
      <rect x="50" y="32" width="6" height="12" rx="3" fill="white" stroke="#0d9488" strokeWidth="2" />
    </svg>
  );
}

interface EditModalProps {
  task: Task;
  onSave: (t: Task) => void;
  onClose: () => void;
}

function EditModal({ task, onSave, onClose }: EditModalProps) {
  const [form, setForm] = useState({ ...task });

  function set(key: keyof Task, val: string | boolean) {
    setForm((f) => ({ ...f, [key]: val }));
  }

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-teal-900">Edit Task</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Task</label>
            <input
              className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              value={form.text}
              onChange={(e) => set("text", e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Category</label>
              <select
                className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
                value={form.category}
                onChange={(e) => set("category", e.target.value)}
              >
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Priority</label>
              <select
                className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
                value={form.priority}
                onChange={(e) => set("priority", e.target.value as Priority)}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Due Date</label>
            <input
              type="date"
              className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              value={form.dueDate}
              onChange={(e) => set("dueDate", e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Reminder</label>
            <input
              type="datetime-local"
              className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              value={form.reminderTime}
              onChange={(e) => { set("reminderTime", e.target.value); set("reminderFired", false); }}
            />
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Notes</label>
            <textarea
              rows={2}
              className="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 resize-none"
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              placeholder="Optional notes…"
            />
          </div>
        </div>

        <div className="flex gap-2 pt-1">
          <button
            onClick={onClose}
            className="flex-1 border border-gray-200 rounded-xl py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => { onSave(form); onClose(); }}
            className="flex-1 bg-teal-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-teal-700 transition-colors"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

interface TaskCardProps {
  task: Task;
  onToggle: (id: string) => void;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
}

function TaskCard({ task, onToggle, onEdit, onDelete }: TaskCardProps) {
  const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && !task.completed;

  return (
    <div className={`task-enter bg-white rounded-2xl border border-gray-100 shadow-sm p-4 group transition-all hover:shadow-md ${task.completed ? "opacity-60" : ""}`}>
      <div className="flex items-start gap-3">
        <button
          onClick={() => onToggle(task.id)}
          className={`mt-0.5 flex-shrink-0 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${task.completed ? "bg-teal-500 border-teal-500" : "border-gray-300 hover:border-teal-400"}`}
        >
          {task.completed && (
            <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          )}
        </button>

        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium text-gray-800 ${task.completed ? "completed-line" : ""}`}>{task.text}</p>

          {task.notes && (
            <p className="text-xs text-gray-400 mt-0.5 truncate">{task.notes}</p>
          )}

          <div className="flex flex-wrap items-center gap-1.5 mt-2">
            <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${PRIORITY_COLORS[task.priority]}`}>
              <span className={`inline-block w-1.5 h-1.5 rounded-full mr-1 ${PRIORITY_DOT[task.priority]}`} />
              {task.priority}
            </span>

            <span className="text-xs px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-100 font-medium">
              {task.category}
            </span>

            {task.dueDate && (
              <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${isOverdue ? "bg-rose-50 text-rose-600 border-rose-200" : "bg-gray-50 text-gray-500 border-gray-200"}`}>
                {isOverdue ? "⚠ " : "📅 "}{new Date(task.dueDate).toLocaleDateString([], { month: "short", day: "numeric" })}
              </span>
            )}

            {task.reminderTime && (
              <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${task.reminderFired ? "bg-gray-50 text-gray-400 border-gray-200" : "bg-violet-50 text-violet-600 border-violet-200"}`}>
                🔔 {formatTime(task.reminderTime)}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onEdit(task)}
            className="p-1.5 rounded-lg text-gray-400 hover:text-teal-600 hover:bg-teal-50 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          </button>
          <button
            onClick={() => onDelete(task.id)}
            className="p-1.5 rounded-lg text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}

const SAMPLE_TASKS: Task[] = [];

export default function App() {
  const [tasks, setTasks] = useState<Task[]>(SAMPLE_TASKS);
  const [newText, setNewText] = useState("");
  const [newCategory, setNewCategory] = useState("Personal");
  const [newPriority, setNewPriority] = useState<Priority>("medium");
  const [newReminder, setNewReminder] = useState("");
  const [newDue, setNewDue] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "completed">("all");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      setTasks((prev) =>
        prev.map((task) => {
          if (task.reminderTime && !task.reminderFired && !task.completed) {
            const reminderDate = new Date(task.reminderTime);
            if (reminderDate <= now) {
              if ("Notification" in window && Notification.permission === "granted") {
                new Notification("Task Reminder 🔔", {
                  body: task.text,
                  icon: "/favicon.ico",
                });
              }
              showToast(`Reminder: "${task.text}"`);
              return { ...task, reminderFired: true };
            }
          }
          return task;
        })
      );
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  }

  function addTask() {
    if (!newText.trim()) return;
    const task: Task = {
      id: genId(),
      text: newText.trim(),
      completed: false,
      priority: newPriority,
      category: newCategory,
      reminderTime: newReminder,
      reminderFired: false,
      createdAt: Date.now(),
      dueDate: newDue,
      notes: "",
    };
    setTasks((prev) => [task, ...prev]);
    setNewText("");
    setNewReminder("");
    setNewDue("");
    setShowAddForm(false);
    showToast("Task added!");
  }

  function toggleTask(id: string) {
    setTasks((prev) => prev.map((t) => t.id === id ? { ...t, completed: !t.completed } : t));
  }

  function deleteTask(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    showToast("Task deleted");
  }

  function saveTask(updated: Task) {
    setTasks((prev) => prev.map((t) => t.id === updated.id ? updated : t));
    showToast("Task updated!");
  }

  const filtered = tasks.filter((t) => {
    const statusMatch = filter === "all" || (filter === "active" ? !t.completed : t.completed);
    const catMatch = categoryFilter === "All" || t.category === categoryFilter;
    return statusMatch && catMatch;
  });

  const active = tasks.filter((t) => !t.completed).length;
  const total = tasks.length;
  const done = tasks.filter((t) => t.completed).length;
  const pct = total === 0 ? 0 : Math.round((done / total) * 100);

  const allCategories = ["All", ...CATEGORIES];

  return (
    <div className="min-h-full bg-gradient-to-br from-teal-700 via-teal-600 to-cyan-500 flex flex-col">
      {/* Header */}
      <header className="pt-8 pb-6 px-4 md:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <RobotIcon className="w-10 h-10" />
            <div>
              <h1 className="text-2xl font-bold text-white leading-tight">TaskBot</h1>
              <p className="text-teal-200 text-sm">Your AI-powered to-do assistant</p>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-3 mb-5">
            {[
              { label: "Total", value: total, icon: "📋" },
              { label: "Active", value: active, icon: "⚡" },
              { label: "Done", value: done, icon: "✅" },
            ].map((s) => (
              <div key={s.label} className="bg-white/15 backdrop-blur-sm rounded-2xl p-3 text-center border border-white/20">
                <div className="text-xl mb-0.5">{s.icon}</div>
                <div className="text-2xl font-bold text-white">{s.value}</div>
                <div className="text-xs text-teal-200">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Progress bar */}
          <div className="bg-white/15 backdrop-blur-sm rounded-2xl p-4 border border-white/20">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-teal-100 font-medium">Progress</span>
              <span className="text-sm font-bold text-white">{pct}%</span>
            </div>
            <div className="h-2 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-700"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main card */}
      <main className="flex-1 bg-gray-50 rounded-t-3xl px-4 md:px-8 pt-6 pb-8">
        <div className="max-w-2xl mx-auto space-y-4">
          {/* Add task button */}
          {!showAddForm ? (
            <button
              onClick={() => { setShowAddForm(true); setTimeout(() => inputRef.current?.focus(), 50); }}
              className="w-full bg-white border-2 border-dashed border-teal-300 rounded-2xl py-4 flex items-center justify-center gap-2 text-teal-600 font-medium hover:bg-teal-50 hover:border-teal-400 transition-all"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add new task
            </button>
          ) : (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 space-y-3">
              <input
                ref={inputRef}
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 font-medium"
                placeholder="What needs to be done?"
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addTask()}
              />

              <div className="grid grid-cols-2 gap-2">
                <select
                  className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                >
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
                <select
                  className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value as Priority)}
                >
                  <option value="low">Low Priority</option>
                  <option value="medium">Medium Priority</option>
                  <option value="high">High Priority</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Due date</label>
                  <input
                    type="date"
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
                    value={newDue}
                    onChange={(e) => setNewDue(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Reminder</label>
                  <input
                    type="datetime-local"
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
                    value={newReminder}
                    onChange={(e) => setNewReminder(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => { setShowAddForm(false); setNewText(""); }}
                  className="flex-1 border border-gray-200 rounded-xl py-2 text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={addTask}
                  disabled={!newText.trim()}
                  className="flex-1 bg-teal-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-teal-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  Add Task
                </button>
              </div>
            </div>
          )}

          {/* Filters */}
          <div className="space-y-2">
            <div className="flex gap-1.5 bg-white rounded-2xl p-1 border border-gray-100 shadow-sm">
              {(["all", "active", "completed"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`flex-1 py-2 rounded-xl text-sm font-medium capitalize transition-all ${filter === f ? "bg-teal-600 text-white shadow-sm" : "text-gray-500 hover:text-teal-600"}`}
                >
                  {f}
                </button>
              ))}
            </div>

            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {allCategories.map((c) => (
                <button
                  key={c}
                  onClick={() => setCategoryFilter(c)}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${categoryFilter === c ? "bg-teal-600 text-white border-teal-600" : "bg-white text-gray-500 border-gray-200 hover:border-teal-300"}`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Task list */}
          <div className="space-y-2">
            {filtered.length === 0 ? (
              <div className="text-center py-12">
                <RobotIcon className="w-16 h-16 mx-auto mb-3 opacity-30" />
                <p className="text-gray-400 font-medium">No tasks here!</p>
                <p className="text-gray-300 text-sm">Add a task to get started.</p>
              </div>
            ) : (
              filtered.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onToggle={toggleTask}
                  onEdit={setEditingTask}
                  onDelete={deleteTask}
                />
              ))
            )}
          </div>

          {done > 0 && filter !== "completed" && (
            <button
              onClick={() => setTasks((p) => p.filter((t) => !t.completed))}
              className="w-full text-center text-xs text-gray-400 hover:text-rose-500 transition-colors py-2"
            >
              Clear {done} completed task{done > 1 ? "s" : ""}
            </button>
          )}
        </div>
      </main>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-teal-900 text-white text-sm px-5 py-3 rounded-2xl shadow-xl z-50 animate-bounce-in flex items-center gap-2">
          <span className="text-teal-400">✓</span> {toast}
        </div>
      )}

      {/* Edit modal */}
      {editingTask && (
        <EditModal
          task={editingTask}
          onSave={saveTask}
          onClose={() => setEditingTask(null)}
        />
      )}
    </div>
  );
}
